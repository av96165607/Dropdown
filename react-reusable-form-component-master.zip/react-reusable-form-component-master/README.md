## React Reusable Form Component

|No. | Component| Tutorial Status | Video Link |
|--- | --- | --- | --- |
|1. | Input Field | Published | https://www.youtube.com/watch?v=HIFxC7Gkgfo |
|2. | Button | Published | https://www.youtube.com/watch?v=8HyXbw3T0P8 |
|3. | Dropdown | Published | https://www.youtube.com/watch?v=bnhamYM3Ubo |
|4. | TextArea | Published | https://www.youtube.com/watch?v=cyNV3XKX2Bk |
|5. | Checkbox | Published | https://www.youtube.com/watch?v=YI003o3xNfU |

[Please watch complete tutorial playlist](https://www.youtube.com/playlist?list=PLtUG3cTN2la1bCd3dvl2Vm9PBo7F413WK)

This project is made by Ghazi Khan for Youtube Channel [CodeWithGhazi](https://www.youtube.com/channel/UCio7gIFilw6wsgbTZAVOBrg).

